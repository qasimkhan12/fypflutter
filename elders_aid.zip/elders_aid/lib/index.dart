// Export pages
export 'sign_in/sign_in_widget.dart' show SignInWidget;
export 'sign_up/sign_up_widget.dart' show SignUpWidget;
export 'home_page/home_page_widget.dart' show HomePageWidget;
export 'elders_view/elders_view_widget.dart' show EldersViewWidget;
export 'chat_page/chat_page_widget.dart' show ChatPageWidget;
export 'old_home/old_home_widget.dart' show OldHomeWidget;
export 'appointments_elders_view/appointments_elders_view_widget.dart'
    show AppointmentsEldersViewWidget;
export 'old_house_book/old_house_book_widget.dart' show OldHouseBookWidget;
export 'add_medicine_reminder/add_medicine_reminder_widget.dart'
    show AddMedicineReminderWidget;
export 'task_elders_view/task_elders_view_widget.dart'
    show TaskEldersViewWidget;
export 'oldhouse_view/oldhouse_view_widget.dart' show OldhouseViewWidget;
export 'appointments_old_house_view/appointments_old_house_view_widget.dart'
    show AppointmentsOldHouseViewWidget;
export 'add_worker/add_worker_widget.dart' show AddWorkerWidget;
export 'workers_page/workers_page_widget.dart' show WorkersPageWidget;
export 'tasks_old_house/tasks_old_house_widget.dart' show TasksOldHouseWidget;
export 'volunteer_view/volunteer_view_widget.dart' show VolunteerViewWidget;
export 'tasks_volunteer_view/tasks_volunteer_view_widget.dart'
    show TasksVolunteerViewWidget;
export 'job_page/job_page_widget.dart' show JobPageWidget;
export 'create_task/create_task_widget.dart' show CreateTaskWidget;
export 'review/review_widget.dart' show ReviewWidget;
