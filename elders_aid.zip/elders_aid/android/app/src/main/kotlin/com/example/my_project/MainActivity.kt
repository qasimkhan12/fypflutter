package com.flutterflow.eldersaid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
